/**
 * Created by michal on 2015-05-11.
 */


myApp.controller('TestController', function ($scope)
{
    $scope.txt = 'hello World Śniadanie'
});