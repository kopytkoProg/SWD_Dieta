/**
 * Created by michal on 2015-05-11.
 */
var myApp = angular.module('myApp', []);


